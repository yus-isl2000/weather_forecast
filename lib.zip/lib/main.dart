import 'package:flutter/material.dart';
import 'package:wether_prep/weather_forcast.dart';

void main() {
  runApp(new MaterialApp(
    home: WeatherForcast(),
  ));
}
