import 'package:flutter/material.dart';
import 'package:wether_prep/model/weather_forecast_model.dart';
import 'package:wether_prep/network/network.dart';

class WeatherForcast extends StatefulWidget {
  @override
  _WeatherForcastState createState() => _WeatherForcastState();
}

class _WeatherForcastState extends State<WeatherForcast> {
  Future<WeatherForecastModel> forecastObject;
  String _cityName = "Toronto";

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    forecastObject = Network().getWeatherForecast(cityName: _cityName);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Forecast'),
      ),
    );
  }
}
